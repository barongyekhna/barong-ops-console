# dark-hardcore 更新记录

## 0.1.0（2026-11-01）

- 第一次按 `jiagui-pack/1` 发：只含选包，`stage: idea`。
- 品类和不适合照抄 `styles/index.md` 那一行。
- 包 id 是暂定的，立包时再定。
