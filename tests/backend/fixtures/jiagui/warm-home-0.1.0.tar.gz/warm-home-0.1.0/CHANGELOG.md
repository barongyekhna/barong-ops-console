# warm-home 更新记录

## 0.1.0（2026-11-01）

- 第一次按 `jiagui-pack/1` 发：只含选包，`stage: planning`。
- 品类、不适合、红线、适配题、变体和先例，都照抄 `styles/warm-home/style-card.md` 和 `styles/index.md`。
- 风格卡里两个变体没有对应的单道题，所以 `triggers` 留空，代码不核对。
- 规划中的包不参加打分。
